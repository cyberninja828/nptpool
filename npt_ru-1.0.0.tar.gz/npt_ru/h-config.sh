#!/usr/bin/env bash

# Source manifest
. h-manifest.conf

# Source wallet config if available (for CUSTOM_TEMPLATE, CUSTOM_URL, etc.)
[[ -f /hive-config/wallet.conf ]] && . /hive-config/wallet.conf

# Function to return miner version
function miner_ver() {
    echo "$CUSTOM_VERSION"
}

# Function to generate config
function miner_config_gen() {
    # Get rig hostname for worker name
    HOSTNAME_ACTUAL="$(hostname)"

    # Parse extra config arguments for custom wallets
    if [[ -n "$CUSTOM_USER_CONFIG" ]]; then
        # Extract --golden-pubkey if provided
        if [[ "$CUSTOM_USER_CONFIG" =~ --golden-pubkey[[:space:]]+([^[:space:]]+) ]]; then
            CUSTOM_GOLDEN_PUBKEY="${BASH_REMATCH[1]}"
        fi
        # Extract --gpu-wallet if provided
        if [[ "$CUSTOM_USER_CONFIG" =~ --gpu-wallet[[:space:]]+([^[:space:]]+) ]]; then
            CUSTOM_GPU_WALLET="${BASH_REMATCH[1]}"
        fi
        # Extract --gpu-secret if provided
        if [[ "$CUSTOM_USER_CONFIG" =~ --gpu-secret[[:space:]]+([^[:space:]]+) ]]; then
            CUSTOM_GPU_SECRET="${BASH_REMATCH[1]}"
        fi
    fi

    # Check if required variables are set
    [[ -z $CUSTOM_TEMPLATE ]] && echo -e "CUSTOM_TEMPLATE (wallet) is not set" && return 1
    [[ -z $CUSTOM_URL ]] && echo -e "CUSTOM_URL (pool) is not set" && return 1

    # Get wallet address from template
    NEPTUNE_WALLET="$CUSTOM_TEMPLATE"

    # Replace wallet placeholders if any
    NEPTUNE_WALLET=$(sed "s/%EWAL%/$EWAL/g" <<< "$NEPTUNE_WALLET")
    NEPTUNE_WALLET=$(sed "s/%DWAL%/$DWAL/g" <<< "$NEPTUNE_WALLET")
    NEPTUNE_WALLET=$(sed "s/%ZWAL%/$ZWAL/g" <<< "$NEPTUNE_WALLET")
    NEPTUNE_WALLET=$(sed "s/%WORKER_NAME%/$WORKER_NAME/g" <<< "$NEPTUNE_WALLET")

    # GPU detection for idle command
    GPU_MODEL=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -n1)

    # ========== НАСТРОЙКИ КОШЕЛЬКОВ ==========
    # Golden Miner pubkey - можно задать через CUSTOM_USER_CONFIG или оставить дефолтный
    # В Flight Sheet добавьте: --golden-pubkey YOUR_PUBKEY
    GOLDEN_PUBKEY="${CUSTOM_GOLDEN_PUBKEY:-3HefipF3enGzErKUUtrXFhjQNb3socw3miVxNQ8m7CYUmdZvRNXTJMpB1HyuiE6HZNToQr23oQgBLLCaAXcDXNUmvCzNH2kHFKLZAho5BRU6nodjx1VpvheNbXiN7evPeqhU}"

    # GPU Miner wallet - можно задать через переменную окружения
    GPU_MINER_WALLET="${CUSTOM_GPU_WALLET:-5k5pgTJR413pug62A6fU5PQxTi1aMiEpxfnFew2mUbefNZ1gecrJ8kHP5so3339PLM}"
    GPU_MINER_SECRET="${CUSTOM_GPU_SECRET:-802138}"
    # =========================================

    if echo "$GPU_MODEL" | grep -qi "5090"; then
        # For RTX 5090
        IDLE_COMMAND="./golden-miner-pool-prover --pubkey=$GOLDEN_PUBKEY --label=rent --name=$HOSTNAME_ACTUAL --threads-per-card=2"
    elif echo "$GPU_MODEL" | grep -qi "3090\|4090"; then
        # For RTX 3090 or 4090 - use alternative gpu miner
        IDLE_COMMAND="./mine_gpu.sh"
    else
        # Default to golden-miner
        IDLE_COMMAND="./golden-miner-pool-prover --pubkey=$GOLDEN_PUBKEY --label=rent --name=$HOSTNAME_ACTUAL --threads-per-card=2"
    fi

    # Create config.json for npt-miner
    cat > $CUSTOM_CONFIG_FILENAME <<EOF
{
  "selected": ["npt-gpu"],
  "algo_list": [
    {
      "id": "npt-gpu",
      "algo": "neptune",
      "pool": "$CUSTOM_URL",
      "worker_name": "$HOSTNAME_ACTUAL",
      "address": "$NEPTUNE_WALLET",
      "config": { "type": "gpu", "option": "all" },
      "idle_algos": ["custom-command-idle-gpu"]
    },
    {
      "id": "custom-command-idle-gpu",
      "command": "$IDLE_COMMAND"
    }
  ]
}
EOF

    # Create mine_gpu.sh helper script for 3090/4090
    cat > /hive/miners/custom/$CUSTOM_NAME/mine_gpu.sh <<GPUEOF
#!/bin/bash
export RIG=\$(hostname)
export SECRET=$GPU_MINER_SECRET
export WALLET="$GPU_MINER_WALLET"
while true; do
    ./gpu
    echo "GPU miner crashed, restarting in 5 seconds..."
    sleep 5
done
GPUEOF
    chmod +x /hive/miners/custom/$CUSTOM_NAME/mine_gpu.sh

    echo "Configuration generated successfully"
    echo "GPU Model: $GPU_MODEL"
    echo "Idle command: $IDLE_COMMAND"

    return 0
}

# NOTE: miner_config_gen is called from h-run.sh, not here!
# Do NOT call it here because it breaks h-stats.sh sourcing in agent
