#!/usr/bin/env bash

# Change to miner directory
cd `dirname $0`

# Load colors for output (if running in terminal)
[ -t 1 ] && . colors

# Source the manifest configuration
. h-manifest.conf

# Generate config (this sources h-config.sh and calls miner_config_gen)
. h-config.sh
miner_config_gen

# Validate required variables
[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Config file $CUSTOM_CONFIG_FILENAME not found${NOCOLOR}" && exit 1

# Create log directory if it doesn't exist
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# Set LD_LIBRARY_PATH to include current directory (for libcuda-hook.so)
export LD_LIBRARY_PATH="$(pwd):${LD_LIBRARY_PATH:-}"

# Watchdog function to monitor miner activity
watchdog() {
    local log_file="$1"
    local timeout=600  # 10 minutes without new logs = restart
    local check_interval=60  # Check every 60 seconds

    while true; do
        sleep $check_interval

        # Check if log file exists and has recent activity
        if [[ -f "$log_file" ]]; then
            local last_modified=$(stat -c %Y "$log_file" 2>/dev/null || echo 0)
            local current_time=$(date +%s)
            local time_diff=$((current_time - last_modified))

            if [[ $time_diff -gt $timeout ]]; then
                echo "$(date '+%Y-%m-%d %H:%M:%S'): WATCHDOG: No activity for ${time_diff}s, restarting miner..." >> "$log_file"
                pkill -9 -f "npt-miner"
                return 1
            fi
        fi
    done
}

# Launch miner with config and logging
echo "Starting Neptune miner..."
echo "Config file: $CUSTOM_CONFIG_FILENAME"
echo "Log file: $CUSTOM_LOG_BASENAME.log"

# Run npt-miner with auto-restart and watchdog
while true; do
    # Clear log file
    > $CUSTOM_LOG_BASENAME.log

    echo "$(date '+%Y-%m-%d %H:%M:%S'): Starting Neptune miner with watchdog..." | tee -a $CUSTOM_LOG_BASENAME.log

    # Start watchdog in background
    watchdog "$CUSTOM_LOG_BASENAME.log" &
    WATCHDOG_PID=$!

    # Run miner
    ./npt-miner run --config $CUSTOM_CONFIG_FILENAME 2>&1 | tee -a $CUSTOM_LOG_BASENAME.log

    # Kill watchdog when miner exits
    kill $WATCHDOG_PID 2>/dev/null || true

    # If miner exits, wait and restart
    echo "$(date '+%Y-%m-%d %H:%M:%S'): Neptune miner stopped. Restarting in 5 seconds..." | tee -a $CUSTOM_LOG_BASENAME.log
    sleep 5
done
