#!/usr/bin/env bash

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Source manifest for configuration from the script's directory
. "$SCRIPT_DIR/h-manifest.conf"

# Get log file location
LOG_FILE="$CUSTOM_LOG_BASENAME.log"

# Check if log file exists
if [[ ! -f $LOG_FILE ]]; then
    stats=""
    khs=0
    exit 1
fi

# Check log freshness (within last 120 seconds)
LOG_TIME=$(stat -c %Y "$LOG_FILE" 2>/dev/null)
CURRENT_TIME=$(date +%s)
TIME_DIFF=$((CURRENT_TIME - LOG_TIME))

if [[ $TIME_DIFF -gt 120 ]]; then
    # Log is stale
    stats=""
    khs=0
    exit 1
fi

# Parse hashrates from log file
hs_array=()
temp_array=()
fan_array=()
total_hs=0

# Get last 150 lines for parsing
LOG_TAIL=$(tail -150 "$LOG_FILE")

# === NEPTUNE MINER PARSING ===
# Format: GPU0 [NVIDIA GeForce RTX 5090] | tip5  | 24.91 MH/s | 100%  | 450 W | 48 °C

# Extract hashrate and temp for each GPU (take LAST occurrence of each GPU)
declare -A gpu_hashrates
declare -A gpu_temps

while IFS= read -r line; do
    # Match: GPU0 [NVIDIA...] | tip5  | 24.91 MH/s
    if echo "$line" | grep -q "GPU[0-9].*|.*MH/s"; then
        # Extract GPU number
        gpu_num=$(echo "$line" | grep -oP 'GPU\K[0-9]+')

        # Extract hashrate (number before MH/s)
        hs=$(echo "$line" | grep -oP '\|\s*tip5\s*\|\s*\K[\d.]+(?=\s*MH/s)')

        # Extract temperature (number before °C)
        temp=$(echo "$line" | grep -oP '\|\s*\K\d+(?=\s*°C)')

        if [[ -n $gpu_num ]] && [[ -n $hs ]]; then
            # Convert MH/s to kH/s (multiply by 1000)
            hs_khs=$(echo "$hs * 1000" | bc 2>/dev/null)
            gpu_hashrates[$gpu_num]=$hs_khs
        fi

        if [[ -n $gpu_num ]] && [[ -n $temp ]]; then
            gpu_temps[$gpu_num]=$temp
        fi
    fi
done <<< "$LOG_TAIL"

# Add to arrays in GPU order
for gpu_num in $(echo "${!gpu_hashrates[@]}" | tr ' ' '\n' | sort -n); do
    hs_array+=(${gpu_hashrates[$gpu_num]})
done

for gpu_num in $(echo "${!gpu_temps[@]}" | tr ' ' '\n' | sort -n); do
    temp_array+=(${gpu_temps[$gpu_num]})
done

# If Neptune format not found, try to get total hashrate
if [[ ${#hs_array[@]} -eq 0 ]]; then
    # Try to find: Total | tip5: 179.06 MH/s
    total_line=$(echo "$LOG_TAIL" | grep -i "Total.*tip5.*MH/s" | tail -1)
    if [[ -n $total_line ]]; then
        total_mhs=$(echo "$total_line" | grep -oP 'tip5:\s*\K[\d.]+(?=\s*MH/s)')
        if [[ -n $total_mhs ]]; then
            # Convert to kH/s
            total_hs=$(echo "$total_mhs * 1000" | bc 2>/dev/null)

            # Get GPU count from nvidia-smi
            gpu_count=$(nvidia-smi --query-gpu=count --format=csv,noheader 2>/dev/null | head -1)
            [[ -z $gpu_count ]] && gpu_count=1

            # Distribute hashrate evenly across GPUs
            avg_hs=$(echo "scale=2; $total_hs / $gpu_count" | bc 2>/dev/null)
            for ((i=0; i<gpu_count; i++)); do
                hs_array+=($avg_hs)
            done
        fi
    fi
fi

# === GOLDEN MINER PARSING (IDLE MODE) ===
# Format: Card-0 speed:  27.20 p/s
if [[ ${#hs_array[@]} -eq 0 ]]; then
    # Get the most recent speed for each card
    declare -A card_speeds
    while IFS= read -r line; do
        # Match: Card-0 speed:  27.20 p/s
        if echo "$line" | grep -q "Card-[0-9].*speed:.*p/s"; then
            card_num=$(echo "$line" | grep -oP 'Card-\K[0-9]+')
            speed=$(echo "$line" | grep -oP 'speed:\s*\K[\d.]+(?=\s*p/s)')
            if [[ -n $speed ]] && [[ -n $card_num ]]; then
                # Store most recent speed for this card
                card_speeds[$card_num]=$speed
            fi
        fi
    done <<< "$LOG_TAIL"

    # Add speeds to array in card order
    for card_num in $(echo "${!card_speeds[@]}" | tr ' ' '\n' | sort -n); do
        hs_array+=(${card_speeds[$card_num]})
    done
fi

# Get GPU stats from nvidia-smi if not already collected
if command -v nvidia-smi &> /dev/null; then
    # Get temperatures if not parsed from log
    if [[ ${#temp_array[@]} -eq 0 ]]; then
        while IFS= read -r temp; do
            temp_array+=($temp)
        done < <(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null)
    fi

    # Get fan speeds
    while IFS= read -r fan; do
        fan_array+=($fan)
    done < <(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null)

    # Get bus IDs (in decimal)
    bus_array=()
    while IFS= read -r bus; do
        # Convert hex bus ID to decimal
        bus_hex=$(echo "$bus" | sed 's/00000000://g' | sed 's/:.*//')
        bus_dec=$((16#$bus_hex))
        bus_array+=($bus_dec)
    done < <(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null)
fi

# Calculate total hashrate in kH/s
total_hs=0
if [[ ${#hs_array[@]} -gt 0 ]]; then
    for h in "${hs_array[@]}"; do
        total_hs=$(echo "$total_hs + $h" | bc 2>/dev/null)
    done
fi
khs=$(echo "scale=2; $total_hs" | bc 2>/dev/null)
[[ -z $khs ]] && khs=0

# Get uptime (time since config was created)
if [[ -f $CUSTOM_CONFIG_FILENAME ]]; then
    config_time=$(stat -c %Y "$CUSTOM_CONFIG_FILENAME" 2>/dev/null)
    uptime=$((CURRENT_TIME - config_time))
else
    uptime=0
fi

# Get accepted/rejected shares from last 100 lines
accepted=$(echo "$LOG_TAIL" | grep -c "Solution was accepted")
rejected=$(echo "$LOG_TAIL" | grep -c "Solution was rejected")
[[ -z $accepted ]] && accepted=0
[[ -z $rejected ]] && rejected=0

# Detect which miner is currently running (check last 30 lines only)
current_algo="neptune"
recent_lines=$(tail -30 "$LOG_FILE")
if echo "$recent_lines" | grep -q "Prover start\|Card-[0-9].*speed.*p/s"; then
    # Golden miner is running
    current_algo="golden-idle"
elif echo "$recent_lines" | grep -q "GPU[0-9].*tip5.*MH/s"; then
    # Neptune miner is running
    current_algo="neptune"
fi

# Build JSON stats using jq
if [[ ${#hs_array[@]} -eq 0 ]]; then
    # No hashrate data found, report 0
    stats=$(jq -nc \
        --arg hs_units "khs" \
        --arg uptime "$uptime" \
        --arg ver "$CUSTOM_VERSION" \
        --argjson ac "$accepted" \
        --argjson rj "$rejected" \
        --arg algo "$current_algo" \
        '{hs: [], $hs_units, temp: [], fan: [], $uptime, $ver, ar: [$ac, $rj], $algo, bus_numbers: []}')
    khs=0
else
    # Build full stats with GPU data
    stats=$(jq -nc \
        --argjson hs "$(printf '%s\n' "${hs_array[@]}" | jq -cs '.')" \
        --arg hs_units "khs" \
        --argjson temp "$(printf '%s\n' "${temp_array[@]}" | jq -cs '.')" \
        --argjson fan "$(printf '%s\n' "${fan_array[@]}" | jq -cs '.')" \
        --arg uptime "$uptime" \
        --arg ver "$CUSTOM_VERSION" \
        --argjson ac "$accepted" \
        --argjson rj "$rejected" \
        --arg algo "$current_algo" \
        --argjson bus_numbers "$(printf '%s\n' "${bus_array[@]}" | jq -cs '.')" \
        '{$hs, $hs_units, $temp, $fan, $uptime, $ver, ar: [$ac, $rj], $algo, $bus_numbers}')
fi

# Output for HiveOS (must be in specific format)
# HiveOS expects only the stats variable to be set, not printed
# The main h-stats.sh will handle the output
